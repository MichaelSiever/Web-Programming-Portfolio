<?php		
	# Michael Siever credentials.php
			
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "itse2302001015";
?>