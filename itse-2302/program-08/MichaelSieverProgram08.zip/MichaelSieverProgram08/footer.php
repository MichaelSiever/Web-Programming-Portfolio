<?php
	# Michael Siever's Program #08 footer.php
	
	$copy = "Copyright &copy; 2019 - " . date('Y') .  " Michael T. Siever";
?>