<?php
	# Michael Siever's Program #08 menu.php
	
	echo 'Some of Austin\'s top restaurants are: <br><br>
	<a href="http://www.trudys.com/">Trudy\'s Tex-Mex</a><br>
	<a href="https://jackallenskitchen.com/">Jack Allen\'s Kitchen</a><br>
	<a href="https://franklinbbq.com/">Franklin Barbeque</a><br>
	<a href="http://ramen-tatsuya.com/">Ramen Tatsu-Ya</a><br>
	<a href="http://www.via313.com/">Via 313 Pizzeria</a><br>';
?>