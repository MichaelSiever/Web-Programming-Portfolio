<?php
	# Michael Siever's Program #08 header.php
	
	date_default_timezone_set('America/Chicago');
	$dateTime = date("m/d/Y h:i:s");
?>