<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Michael T. Siever selfprocessor.php</title>
		<link href="program-07.css" rel="stylesheet">
	</head>

	<body>
	
		<h1>selfprocessor.php</h1>
	
		<hr>
		
		<h2>Requirement #08</h2>

		<?php
			// Intitiating all values to null
			$nameErr = $movieErr = $foodErr = "";
			$daysofweek = $monthsofyear = $name = $movie = $food = $season = 
			$comments = $color = $bday = $email = $quantity = $points = "";
			
			if($_SERVER["REQUEST_METHOD"] == "POST") {
				$daysofweek = validate_input($_POST["daysofweek"]);
            	$monthsofyear = validate_input($_POST["monthsofyear"]);
            	if(empty($_POST["name"])) {
        			$nameErr = "Name is required";
    			} else {
        			$name = validate_input($_POST["name"]);
        			if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
            			$nameErr = "Only letters and white space allowed";
        			}
    			}
    			
    			if(empty($_POST["movie"])) {
        			$movieErr = "Movie is required";
    			} else {
        			$movie = validate_input($_POST["movie"]);
        			if (!preg_match("/^[a-zA-Z0-9 ]*$/", $movie)) {
            			$movieErr = "Only letters, numbers, and white space allowed";
        			}
    			}	
    			
    			if(empty($_POST["food"])) {
        			$foodErr = "Food is required";
    			} else {
        			$food = validate_input($_POST["food"]);
        			if (!preg_match("/^[a-zA-Z ]*$/", $food)) {
            			$foodErr = "Only letters and white space allowed";
        			}
    			}   
    							
    			$season = validate_input($_POST["season"]);
    			
    			if (empty($_POST["comments"])) {
    				$comments = "";
  				} else {
    				$comments = validate_input($_POST["comments"]);
  				}
  				
  				$color = validate_input($_POST["favcolor"]);
				$email = validate_input($_POST["email"]);
				$quantity = validate_input($_POST["quantity"]);
				$points = validate_input($_POST["points"]);
				$bday = validate_input($_POST["bday"]);
			}
			
			function validate_input($data) {
        		$data = trim($data);
        		$data = stripslashes($data);
        		$data = htmlspecialchars($data);
        		return $data;
    		}
    	?>
		
		<p><span class="error">* Required field.</span></p>
		
		<form action="<?=htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post"
		id ="form1">
			Choose a day of the week: 
			<input list="daysofweek" name="daysofweek">
			<datalist id="daysofweek">
        		<option value="Sunday">
        		<option value="Monday">
        		<option value="Tuesday">
        		<option value="Wednesday">
    			<option value="Thursday">
    			<option value="Friday">
    			<option value="Saturday">
			</datalist><br><br>
	
			Choose a month of the year: 
			<input list="monthsofyear" name="monthsofyear">
			<datalist id="monthsofyear">
        		<option value="January">
        		<option value="February">
        		<option value="March">
        		<option value="April">
        		<option value="May">
        		<option value="June">
        		<option value="July">
        		<option value="August">
        		<option value="September">
        		<option value="October">
        		<option value="November">
        		<option value="December">
			</datalist><br><br>
			
			Name:
        	<input type="text" name="name" 
        	value="<?php if(isset($_POST["name"])) echo $_POST["name"];?>">
        	<span class="error">* <?php echo $nameErr;?></span>
    		<br><br>
   		 	Favorite Movie:
        	<input type="text" name="movie" 
        	value="<?php if(isset($_POST["movie"])) echo $_POST["movie"];?>">
        	<span class="error">* <?php echo $movieErr;?></span>
    		<br><br>
    		Favorite Food:
        	<input type="text" name="food"
        	value="<?php if(isset($_POST["food"])) echo $_POST["food"];?>">
        	<span class="error">* <?php echo $foodErr;?></span>
    		<br><br>
    		Favorite Season:
    		<?php if(isset($_POST["season"]) == "true") echo $_POST["season"] ." was selected";?>
    		<input type="radio" name="season" value="Spring">Spring
        	<input type="radio" name="season" value="Summer" checked>Summer
        	<input type="radio" name="season" value="Fall">Fall
        	<input type="radio" name="season" value="Winter">Winter
    		<br><br>
    		Comments (These are optional):<br>
        	<textarea name="comments" rows="4" cols="50" wrap="hard">
        	<?php if(isset($_POST["comments"])) echo $_POST["comments"];?>
        	</textarea>
    		<br><br>
    		Favorite color: 
			<input type="color" name="favcolor" 
			value="<?php if(isset($_POST["favcolor"])) echo $_POST["favcolor"];?>">
			<br><br>
			E-mail:
  			<input type="email" name="email" autocomplete="on" placeholder="E-mail"
  			value="<?php if(isset($_POST["email"])) echo $_POST["email"];?>">
  			<br><br>
  			Quantity (between 1 and 5):
  			<input type="number" name="quantity" min="1" max="5"
  			value="<?php if(isset($_POST["quantity"])) echo $_POST["quantity"];?>">
  			<br><br>
  			Points (between 0 and 10):
  			<input type="range" name="points" min="0" max="10" step="2"
  			value="<?php if(isset($_POST["points"])) echo $_POST["points"];?>">
  			<br><br>
  			<input type="submit" value="Submit">
  			<br><br>
		</form>
		
		Birthday:
		<input type="date" name="bday" form="form1"
		value="<?php if(isset($_POST["bday"])) echo $_POST["bday"];?>">
		<br><br>
		
		<hr>
		
    	<h2>Your Input:</h2>
		Day of Week: <?php echo $daysofweek;?><br>
		Month: <?php echo $monthsofyear;?><br>
		Name: <?php echo $name;?><br>
		Favorite Movie: <?php echo $movie;?><br>
		Favorite Food: <?php echo $food;?><br>
		Favorite Season: <?php echo $season;?><br>
		Comments: <?php echo $comments;?><br>
		Favorite Color (in hexidecimal notation): <?php echo $color;?><br>
		E-mail: <?php echo $email;?><br>
		Quantity: <?php echo $quantity;?><br>
		Points: <?php echo $points;?><br>
		Birthday: <?php echo $bday;?><br>
		
		<hr>
		
		<a href="index.php">Return to previous page</a>
	</body>
</html>