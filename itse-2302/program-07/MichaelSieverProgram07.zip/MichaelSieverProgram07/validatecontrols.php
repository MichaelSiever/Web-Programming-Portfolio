<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Michael T. Siever validatecontrols.php</title>
		<link href="program-07.css" rel="stylesheet">
	</head>

	<body>
	
		<h1>validatecontrols.php</h1>
	
		<hr>
		
		<h2>Requirement #09</h2>

		<?php
			$nameErr = $emailErr = $websiteErr = $devtypeErr = "";
			$name = $email = $website = $devtype = "";
			
			if($_SERVER["REQUEST_METHOD"] == "POST") {    
    			if(empty($_POST["name"])) {
        			$nameErr = "Name is required";
    			} else {
        			$name = validate_input($_POST["name"]);
        			if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
            			$nameErr = "Only letters and white space allowed";
        			}
    			}
    			
    			if(empty($_POST["email"])) {
        			$emailErr = "Email is required";
    			} else {
        			$email = validate_input($_POST["email"]);
        			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  						$emailErr = "Invalid email format";
					}
    			}
    			
    			if (empty($_POST["website"])) {
        			$websiteErr = "Website is required";
    			} else {
        			$website = validate_input($_POST["website"]);
        			if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website)) {
  						$websiteErr = "Invalid URL";
					}
    			}
    			
    			if (empty($_POST["devtype"])) {
    				$devtypeErr = "Developer type is required";
    			} else {
        			$devtype = validate_input($_POST["devtype"]);
        		}
			}
			
			function validate_input($data) {
        		$data = trim($data);
        		$data = stripslashes($data);
        		$data = htmlspecialchars($data);
        		return $data;
    		}		
    	?>
		
		<p><span class="error">* Required field.</span></p>
		
		<form action="<?=htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
			Name:
        	<input type="text" name="name" 
        	value="<?php if(isset($_POST["name"])) echo $_POST["name"];?>">
        	<span class="error">* <?php echo $nameErr;?></span>
    		<br><br>
			Email:
            <input type="text" name="email" 
            value="<?php if(isset($_POST["email"])) echo $_POST["email"];?>">
			<span class="error">* <?php echo $emailErr;?></span>
			<br><br>
			Website:
            <input type="text" name="website"
            value="<?php if(isset($_POST["website"])) echo $_POST["website"];?>">
            <span class="error">* <?php echo $websiteErr;?></span>
			<br><br>
			Developer Type:
    		<input type="radio" name="devtype" value="Front End">Front End
        	<input type="radio" name="devtype" value="Server Side">Server Side
        	<input type="radio" name="devtype" value="Full Stack">Full Stack
        	<span class="error">* <?php echo $devtypeErr;?></span>
        	<br><br>
        	<?php if (isset($_POST["devtype"]) == "true") echo $_POST["devtype"] ." was selected";?>
    		<br>
    		<input type="submit" name="submit" value="Submit">
		</form>
		
		<hr>

		<h2>Your Input:</h2>
    	Name: <?php echo $name;?><br>
    	E-mail: <?php echo $email;?><br>
    	Website: <?php echo $website;?><br>
    	Developer Type: <?php echo $devtype;?><br>
    	
    	<hr>
    	
    	<a href="index.php">Return to previous page</a>
	</body>
</html>