// JavaScript Functions for Michael T. Siever Program 1
function Req1LightOnOff() {
	var pic = document.getElementById("Light Bulb");
	if (pic.src.match("bulb_is_off")) {
		pic.src = "images/pic_bulb_is_on.gif";
	} else {
		pic.src = "images/pic_bulb_is_off.gif";
	}
}

function Req2DateTimeChange() {
	 var dt = new Date(); // Calls built-in new Date/Time function
     document.getElementById("DT Change").innerHTML = dt;
}

function Req7ClearPage() {
	var x = document.body;
	document.write("<p></p>");
	document.write("<body style='text-align: center; background-color: yellow;'><p>Page Cleared. Click <a href='index.html'>here</a> to go return to the previous page.</p></body>");
}

function Req8TextTransform() {
	var y = document.getElementById("changeText");
	y.style.color = "crimson";
	y.style.fontSize = "30px";
	console.log(y.innerHTML);
}

function Req9GetLocation() {
	var x = document.getElementById("coordinates");
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(Req9ShowPos);
	} else { 
		x.innerHTML = "Geolocation is not supported by this browser.";
	}
}

function Req9ShowPos(position) {
			var x = document.getElementById("coordinates");
			x.innerHTML = "Latitude: " + position.coords.latitude + 
			  "<br>Longitude: " + position.coords.longitude;
}

function Req10DoMath() {
	var first = parseInt(document.getElementById("first").value);
    var second = parseInt(document.getElementById("second").value);
    var sum = "First number plus second number: " +(first + second);
    var diff = "First number minus second number: " + (first - second);
    var prod = "First number times second number: " + (first * second);
    var quot = "First number divided by second number: " + (first / second);
    document.getElementById("sum").innerHTML = sum;
    document.getElementById("difference").innerHTML = diff;
    document.getElementById("product").innerHTML = prod;
    document.getElementById("quotient").innerHTML = quot;
}

function Req11StringAdd() {
    var first = document.getElementById("primero").value;
    var second = document.getElementById("segundo").value;
    document.getElementById("AddString").innerHTML = "The two numeric strings concatenated together are "
     + (first + second) + ".";
}

function Req12RollTheDice() {
	var num = parseInt(document.getElementById("VivaLasVegas").value);
    var modulus = num % 2;
    var image = document.getElementById("DiceDiceBaby");
    if(modulus == 0) {
         image.src="images/6Die.png" ;
    } else {
        image.src="images/5Die.png" ;
    }
}

function Req13CheckRepublic() {
    var checknum = parseInt(document.getElementById("ChecksMarksTheSpot").value);
    if(document.getElementById("PlusOne").checked  == true) {
        checknum += 1;
    } if(document.getElementById("TakeAwayOne").checked == true) {
        checknum -= 1;
    }
    document.getElementById("Checkmate").innerHTML = "The value of the number you entered is now: " + checknum;
}

function Req14ChangeName() {
    var chosenname = document.getElementById("SelectName").value;
    document.getElementById("AndBingoWasHisNameO").innerHTML = chosenname;

    console.log(chosenname);
    if(chosenname == "Name 1") {
        document.getElementById("AndBingoWasHisNameO").style.color="olive";
    } else if(chosenname == "Name 2") {
        document.getElementById("AndBingoWasHisNameO").style.color="royalblue";
    } else if(chosenname == "Name 3") {
        document.getElementById("AndBingoWasHisNameO").style.color="crimson";
    } else if(chosenname == "Name 4") {
        document.getElementById("AndBingoWasHisNameO").style.color="darkgreen";
    }
}

function Req15StopDropAndRoll(ev) {
  ev.preventDefault();
}

function Req15MajorDragMan(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
}

function Req15DropAndGiveMeFifty(ev) {
  ev.preventDefault();
  var data = ev.dataTransfer.getData("text");
  ev.target.appendChild(document.getElementById(data));
}

function Req16BackChange() {
    document.getElementById("ChChChChanges").style.backgroundColor="#FF6347"
}

function Req16ChangeBack() {
    document.getElementById("ChChChChanges").style.backgroundColor="#ffffff"
}