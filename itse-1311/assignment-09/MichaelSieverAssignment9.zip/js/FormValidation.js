function clearOut(form) {
    /* Resets input boxes; removes red borders and text from message area. */
    document.getElementById("name").value = "";
    document.getElementById("remail1").value = "";
    document.getElementById("remail2").value = "";
    document.getElementById("subject").value = "";
    document.getElementById("message").value = "";
    document.getElementById("name").classList.add("normal-box");
    document.getElementById("name").classList.remove("error-box");
    document.getElementById("remail1").classList.add("normal-box");
    document.getElementById("remail1").classList.remove("error-box");
    document.getElementById("remail2").classList.add("normal-box");
    document.getElementById("remail2").classList.remove("error-box");
    document.getElementById("subject").classList.add("normal-box");
    document.getElementById("subject").classList.remove("error-box");
    document.getElementById("message").classList.add("normal-box");
    document.getElementById("message").classList.remove("error-box");
    document.getElementById("message-area").innerHTML = "";
}

function verfiyName() {
    /* Verifies info from name input box. If empty, returns false; else, returns name. */
    var name = document.getElementById("name").value;
        name = name.trim();

        if (name.length == 0 ) {
        return false;
        }
    else
    {
        document.getElementById("message-area").classList.remove("error-text");
        document.getElementById("message-area").classList.add("normal-text");
        document.getElementById("name").classList.add("normal-box");            
        document.getElementById("name").classList.remove("error-box");
        return name;
        }
}

function verifyEmail1() {
    /* Verifies info from remail1 input box. If remail1 is empty or if remail1 does not have a "@" character, returns false; else, returns email1. */
    var email1 = document.getElementById("remail1").value;
        email1 = email1.trim();
    var foundAt = -1;
    var len = email1.length;

    for (var i = 0; i < len && foundAt == -1; i++){
        if (email1[i] == "@"){
            foundAt += i;
        }
    }

        if (email1.length == 0 || foundAt < 0 || foundAt + 3 > len) {
        return false;
        }
    else
    {
        document.getElementById("message-area").classList.remove("error-text");
        document.getElementById("message-area").classList.add("normal-text");
        document.getElementById("remail1").classList.add("normal-box");         
        document.getElementById("remail1").classList.remove("error-box");
        return email1;
    }
}

function verifyEmail2() {
    /* Verifies info from remail2 input box. If empty or if remail2 does not match remail1, returns false; else, returns email2. */
    var email2 = document.getElementById("remail2").value;
        email2 = email2.trim();

        if (email2.length == 0 || email2 != verifyEmail1()) {
        return false;
        }
    else
    {
        document.getElementById("message-area").classList.remove("error-text");
        document.getElementById("message-area").classList.add("normal-text");
        document.getElementById("remail2").classList.add("normal-box");         
        document.getElementById("remail2").classList.remove("error-box");
        return email2;   
    }
}

function verifySubject() {
    /* Verifies info from subject input box. If empty, return false; else, returns subject. */
        var subject = document.getElementById("subject").value;
        subject = subject.trim();

        if (subject.length == 0) {
        return false;
        }
    else
    {
        document.getElementById("message-area").classList.remove("error-text");
        document.getElementById("message-area").classList.add("normal-text");
        document.getElementById("subject").classList.add("normal-box");         
        document.getElementById("subject").classList.remove("error-box");
        return subject;   
    }
}

function verifyMessage() {
    /* Verifies info from message input box. If less than 10 characters, returns false; else, returns message. Message set at input box to take a max of only 1000 characters.*/
    var message = document.getElementById("message").value;
    message= message.trim();

        if (message.length < 10) {
        return false;
        }
    else
    {
        document.getElementById("message-area").classList.remove("error-text");
        document.getElementById("message-area").classList.add("normal-text");
        document.getElementById("message").classList.add("normal-box");         
        document.getElementById("message").classList.remove("error-box");
        return message;
    }
}

function send() {
    var name = verfiyName();
    var email1 = verifyEmail1();
    var email2 = verifyEmail2();
    var subject = verifySubject();
    var message = verifyMessage();
    var errmsg = '';

    if (name == false){
        errmsg += "Please enter your name.<br>";
        document.getElementById("name").classList.remove("normal-box");         
        document.getElementById("name").classList.add("error-box");
        document.getElementById("message-area").classList.add("error-text");
        document.getElementById("message-area").classList.remove("normal-text");
		document.getElementById("name").value = "";
    }
    if (email1 == false){
        errmsg += "Please enter your email address.<br>";
        document.getElementById("remail1").classList.remove("normal-box");              
        document.getElementById("remail1").classList.add("error-box");
        document.getElementById("message-area").classList.add("error-text");
        document.getElementById("message-area").classList.remove("normal-text");
		document.getElementById("remail1").value = "";
    }
    if (email2 == false){
        errmsg += "Please confirm your email address.<br>";
        document.getElementById("remail2").classList.remove("normal-box");              
        document.getElementById("remail2").classList.add("error-box");
        document.getElementById("message-area").classList.add("error-text");
        document.getElementById("message-area").classList.remove("normal-text");
		document.getElementById("remail2").value = "";
    }
    if (subject == false){
        errmsg += "Please input a subject.<br>";
        document.getElementById("subject").classList.remove("normal-box");              
        document.getElementById("subject").classList.add("error-box");
        document.getElementById("message-area").classList.add("error-text");
        document.getElementById("message-area").classList.remove("normal-text");
		document.getElementById("subject").value = "";
    }
    if (message == false){
        errmsg += "Message requires a minimum of 10 characters and a maximum of 1000 characters.<br>";
        document.getElementById("message").classList.remove("normal-box");              
        document.getElementById("message").classList.add("error-box");
        document.getElementById("message-area").classList.add("error-text");
        document.getElementById("message-area").classList.remove("normal-text");
		document.getElementById("message").value = "";
    }
    if (errmsg == ''){
        document.getElementById("message-area").classList.remove("error-text");
        document.getElementById("message-area").classList.add("normal-text");
        document.getElementById("message-area").innerHTML = "Message Sent.";
        console.log("Submitted Form Data:");
        console.log("Name: " + name);
        console.log("E-mail: "+ email2);
        console.log("Subject: " + subject);
        console.log("Message: " + message);
		postSubmit();
    }
    else{
        document.getElementById("message-area").classList.add("error-text");
        document.getElementById("message-area").classList.remove("normal-text");
        document.getElementById("message-area").innerHTML = errmsg;
    }
}

function show() {
    var t = "edu";
    var yz = "michael.siever";
    var a = "@";
    var u = "austincc.";
    var j = "mailto:";
    document.getElementById("3mai1").classList.add("clicked-text");
    document.getElementById("3mai1").innerHTML = "<a href = " + j + yz + a + "g." + u + t + ">" + yz + a + "g." + u + t + "</a>";
}

function postSubmit() {
	/* This will clear out the contact form upon a successful submission */
	var name = document.getElementById("name").value;
	var email1 = document.getElementById("remail1").value;
	var email2 = document.getElementById("remail2").value;
	var subject = document.getElementById("subject").value;
	var message = document.getElementById("message").value;
	document.getElementById("name").value = "";
    document.getElementById("remail1").value = "";
    document.getElementById("remail2").value = "";
    document.getElementById("subject").value = "";
    document.getElementById("message").value = "";
}